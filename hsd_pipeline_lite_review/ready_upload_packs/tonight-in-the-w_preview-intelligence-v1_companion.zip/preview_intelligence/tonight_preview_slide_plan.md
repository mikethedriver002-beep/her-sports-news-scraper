# Tonight Preview Slide Plan

Version: v3.2.16-mermaid-preview-intelligence-v1.0
Generated: 2026-06-14T17:01:50.374861+00:00

## Slide 1 — Cover
- Function: cover
- Keep the slate compactly visible with both matchups and tip times.
- Make it feel like an event, not a flat schedule board.

## Slide 2 — What to know tonight
- Function: add editorial value
- Do not repeat the full slate board function from Slide 1.
- Atlanta Dream at Toronto Tempo: Who sets the tone early? Watch how Atlanta Dream and Toronto Tempo handle pace, execution, and late-game possessions.
- Washington Mystics at New York Liberty: Which side owns the key moments? Watch how Washington Mystics and New York Liberty handle pace, execution, and late-game possessions.

## Slide 3 — Storylines to know
- Do NOT force a player slide.
- Use two matchup panels or two storyline cards instead.
- Atlanta Dream at Toronto Tempo: Can Atlanta Dream grab the road spotlight, or does Toronto Tempo control the matchup at home?
- Washington Mystics at New York Liberty: Can Washington Mystics grab the road spotlight, or does New York Liberty control the matchup at home?

## Slide 4 — CTA
- Function: engagement
- Headline: Which game are you locked in for?
- Subheadline: Drop your pick before tipoff
- Ask for a matchup pick or which game viewers are watching first.
