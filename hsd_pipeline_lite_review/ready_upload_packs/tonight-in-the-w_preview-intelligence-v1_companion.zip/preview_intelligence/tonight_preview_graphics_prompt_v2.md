# Tonight in the W — Graphics Prompt Override

Version: v3.2.16-mermaid-preview-intelligence-v1.0
Generated: 2026-06-14T17:01:50.374916+00:00

Create a premium Her Sports Daily 4-slide 1080x1350 carousel for Tonight in the W.

Non-negotiable rules:
1. Use only the exact uploaded team logos and exact uploaded player/person images.
2. Do not fetch, substitute, or invent logos or players.
3. Every listed slate game must appear somewhere in the carousel.
4. Slide 2 must not duplicate the function of Slide 1.
5. For player-based slides, every team in the slate must be represented with at least one exact attached player image. If that is not possible, replace the player slide with a storyline slide.
6. Do not create a three-team player grid for a two-game slate.
7. Keep one HSD watermark only, top-left.
8. Improve panel contrast/support treatment for dark logos like Toronto Tempo without changing the official logo itself.

Featured slate:
- Atlanta Dream at Toronto Tempo
- Washington Mystics at New York Liberty

Approved slide structure:
- Slide 1: Cover with both games and times, event energy.
- Slide 2: What to know tonight with one value-add hook per game.
- Slide 3: Storylines to know. Do NOT use a player slide because not all slate teams have exact attached player images.
  - Atlanta Dream at Toronto Tempo: Can Atlanta Dream grab the road spotlight, or does Toronto Tempo control the matchup at home?
  - Washington Mystics at New York Liberty: Can Washington Mystics grab the road spotlight, or does New York Liberty control the matchup at home?
- Slide 4: CTA. Headline 'Which game are you locked in for?'. Subheadline 'Drop your pick before tipoff'.

Exact-logo display notes:
- Toronto Tempo: Use the exact attached logo asset, but increase panel contrast and supporting edge glow so the dark logo does not get buried.
- Washington Mystics: Keep exact attached logo asset and strong contrast.
