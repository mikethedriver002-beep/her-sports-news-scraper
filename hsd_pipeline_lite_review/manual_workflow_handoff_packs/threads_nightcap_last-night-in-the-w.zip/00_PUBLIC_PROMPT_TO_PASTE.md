# HSD Public Prompt

Create a premium Her Sports Daily social asset.

Platform: Threads
Slot: nightcap
Story: Last Night in the W
League: WNBA
Content type: result_or_recap

Public display direction:
- Last Night in the W: what this changes next.
- Keep it fast to read, premium, and social-first.
- Use clean HSD editorial language.
- CTA idea: What changes next because of this?
