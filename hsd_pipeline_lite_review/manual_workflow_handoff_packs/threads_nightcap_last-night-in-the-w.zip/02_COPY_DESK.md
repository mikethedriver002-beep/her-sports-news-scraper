# Copy Desk

Last Night in the W A result worth revisiting through what comes next.

First comment:
What changes next because of this?
