# Threads Copy

Last Night in the W Biggest takeaway?
