# First Comment

What was the swing moment?
