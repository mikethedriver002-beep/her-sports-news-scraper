# Copy Desk

Last Night in the W The result matters because it changes the conversation, not just the scoreboard.

First comment:
What was the swing moment?
