# First Comment

Which side are you trusting tonight?
