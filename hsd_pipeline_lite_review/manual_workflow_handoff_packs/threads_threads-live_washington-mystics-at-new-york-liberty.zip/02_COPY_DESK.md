# Copy Desk

Washington Mystics at New York Liberty Tonight’s HSD watch point: pace, execution, and who owns the pressure moments.

First comment:
Which side are you trusting tonight?
