# Threads Copy

Twice as Nice: Iwai Twins Fire 7-Under 63, Climb the Leaderboard at Dow Championship June 12, 2026 The LPGA board is getting spicy. Are we paying enough attention?
