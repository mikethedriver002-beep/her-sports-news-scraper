# First Comment

Are we underrating this LPGA moment?
