# HSD Public Prompt

Create a premium Her Sports Daily social asset.

Platform: Threads
Slot: threads_morning
Story: Twice as Nice: Iwai Twins Fire 7-Under 63, Climb the Leaderboard at Dow Championship June 12, 2026
League: LPGA
Content type: official_news_article

Public display direction:
- The LPGA lane has a real storyline: Twice as Nice: Iwai Twins Fire 7-Under 63, Climb the Leaderboard at Dow Championship June 12, 2026.
- Keep it fast to read, premium, and social-first.
- Use clean HSD editorial language.
- CTA idea: Are we underrating this LPGA moment?
