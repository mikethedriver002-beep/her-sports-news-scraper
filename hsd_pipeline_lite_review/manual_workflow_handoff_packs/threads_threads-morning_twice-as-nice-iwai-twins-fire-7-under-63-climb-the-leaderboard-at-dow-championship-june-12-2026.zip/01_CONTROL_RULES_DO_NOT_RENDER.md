# Control Rules - Do Not Render

Version: v3.3.6-mermaid-assignment-handoff-v2.6
Freshness label: fresh
Asset policy: exact logos only; exact player assets only; no generated players, jerseys, logos, stats, quotes, injuries, or scores.
Use player graphics when appropriate only if exact approved player assets exist.
Do not use blocked or held preview instructions.
