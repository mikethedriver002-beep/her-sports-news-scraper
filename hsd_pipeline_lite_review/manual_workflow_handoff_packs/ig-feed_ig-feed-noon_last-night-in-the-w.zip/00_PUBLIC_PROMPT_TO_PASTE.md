# HSD Public Prompt

Create a premium Her Sports Daily social asset.

Platform: IG Feed
Slot: ig_feed_noon
Story: Last Night in the W
League: WNBA
Content type: result_or_recap

Public display direction:
- Last Night in the W: put this result on the board.
- Keep it fast to read, premium, and social-first.
- Use clean HSD editorial language.
- CTA idea: What was the swing moment?
