# Asset Instructions

Recommended output: graphics_prompt_plus_caption

- Use exact team/league logos only when visible.
- Player graphics are required when appropriate, but only exact approved assets may be used.
- If exact player assets are unavailable, use a text-forward editorial card with exact logos.
- Do not fetch or invent assets inside graphics chat.
