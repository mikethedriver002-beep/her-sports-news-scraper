# HSD Public Prompt

Create a premium Her Sports Daily social asset.

Platform: IG Feed
Slot: ig_feed_evening_preview
Story: Washington Mystics at New York Liberty
League: WNBA
Content type: preview_event

Public display direction:
- Washington Mystics at New York Liberty: the game lane to watch.
- Keep it fast to read, premium, and social-first.
- Use clean HSD editorial language.
- CTA idea: Which side are you trusting tonight?
