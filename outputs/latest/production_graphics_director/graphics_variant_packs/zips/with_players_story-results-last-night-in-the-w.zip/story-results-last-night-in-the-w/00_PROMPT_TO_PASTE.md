HSD GRAPHICS PRODUCTION.

Use the uploaded ZIP only.

Create premium Her Sports Daily graphics for:
Last Night in the W

Variant: with_players
PLAYER MODE: WITH PLAYERS.
Use the uploaded approved player headshots if they improve the graphic. Do not invent player photos. Do not use generic blank headshots. If player_mode says team_candidate_players_review_required, these images are optional visual candidates, not locked statistical claims. Do not add player stats unless supplied in the dossier.

Detected teams: dallas_wings;golden_state_valkyries;las_vegas_aces;los_angeles_sparks

Approved / candidate player assets included:
- Alanna Smith | dallas_wings | uploaded file: assets/players/dallas_wings_alanna_smith.png
- Alysha Clark | dallas_wings | uploaded file: assets/players/dallas_wings_alysha_clark.png
- Ashten Prechtel | golden_state_valkyries | uploaded file: assets/players/golden_state_valkyries_ashten_prechtel.png
- Cecilia Zandalasini | golden_state_valkyries | uploaded file: assets/players/golden_state_valkyries_cecilia_zandalasini.png
- A'ja Wilson | las_vegas_aces | uploaded file: assets/players/las_vegas_aces_a_ja_wilson.png
- Brianna Turner | las_vegas_aces | uploaded file: assets/players/las_vegas_aces_brianna_turner.png

Non-negotiables:
- Use only uploaded assets.
- Do not fetch logos.
- Do not invent players.
- Do not invent stats.
- Do not use fake player photos.
- Do not use generic blank headshots.
- Do not create white dashboard cards.
- Do not render internal QA labels or workflow language.
- Keep all text readable and inside safe zones.
- Use the official HSD watermark only if included.
- Export each slide as a separate PNG.
- Send the finished images in a ZIP.

Use the premium HSD style:
dark cinematic sports-media background, bold condensed typography, strong team color accents, clean hierarchy, ESPN/BR energy, no clutter.

Caption to use after graphics are generated:
Last Night in the W. • Minnesota Lynx 107 · Portland Fire 74 • Golden State Valkyries 78 · Los Angeles Sparks 58 • Dallas Wings 96 · Las Vegas Aces 66 Dallas made people look twice. Minnesota made a statement. Two finals, two very different kinds of pressure, and one night that gave us more than a box score. Which result mattered most? 🏀 #HerSportsDaily #WomensSports #WNBA #Basketball #DallasWings #GoldenStateValkyries #LasVegasAces #LASparks

Manual prompt dossier:
# HSD Manual Prompt Dossier — Last Night in the W

Packet: `story-results_last-night-in-the-w`
Platform: `IG Stories / Threads`
Family: `wnba_results_roundup`
Quality: `rich`

## Brand Style

Premium women’s sports editorial. Dark high-contrast background. Bold condensed sports typography. Cinematic lighting. Clean hierarchy. No white dashboard cards. No tiny text. Use the official HSD watermark exactly.

## Evidence

Last Night in the W | WNBA | results_roundup | Minnesota Lynx 107 · Portland Fire 74 | Golden State Valkyries 78 · Los Angeles Sparks 58 | Dallas Wings 96 · Las Vegas Aces 66 | Minnesota Lynx 107 · Portland Fire 74 | Golden State Valkyries 78 · Los Angeles Sparks 58 | Dallas Wings 96 · Las Vegas Aces 66 | story_35430d10689207 | last-night-in-the-w | Last Night in the W | ig_story_final_scores | 2026-06-15 | 3 | 5 | ["event_68fa88dd191fb6", "event_773d480cadd79b", "event_f4275145344771"] | Dallas Wings; Golden State Valkyries; Las Vegas Aces; Los Angeles Sparks; Minnesota Lynx; Portland Fire | Minnesota Lynx 107 · Portland Fire 74 | Golden State Valkyries 78 · Los Angeles Sparks 58 | Dallas Wings 96 · Las Vegas Aces 66 | ready_with_review | ready_for_graphics_review | ig_story_results_uploa

## Carousel Plan

### Slide 1: Cover
On-image copy: Last Night in the W
Visual direction: Premium dark scoreboard cover.

### Slide 2: Scores
On-image copy: Minnesota Lynx 107 · Portland Fire 74 | Golden State Valkyries 78 · Los Angeles Sparks 58 | Dallas Wings 96 · Las Vegas Aces 66
Visual direction: Large score rows with official team logos.

### Slide 3: Dallas made noise
On-image copy: Wings over Aces
Visual direction: Spotlight Dallas result.

### Slide 4: Minnesota sent a message
On-image copy: Lynx over Fire
Visual direction: Spotlight Minnesota result.

### Slide 5: CTA
On-image copy: Best win of the night?
Visual direction: Question-first HSD end slide.

## Caption

Last Night in the W.

• Minnesota Lynx 107 · Portland Fire 74
• Golden State Valkyries 78 · Los Angeles Sparks 58
• Dallas Wings 96 · Las Vegas Aces 66

Dallas made people look twice. Minnesota made a statement. Two finals, two very different kinds of pressure, and one night that gave us more than a box score.

Which result mattered most? 🏀

#HerSportsDaily #WomensSports #WNBA #Basketball #DallasWings #GoldenStateValkyries #LasVegasAces #LASparks

## Negative Prompt

No fake players. No invented stats. No unapproved headshots. No generic blank headshots. No cut-off names. No low-contrast text. No extra teams. No white panels.

