# Upload instructions: Volleyball Results Roundup

Upload `00_PROMPT_TO_PASTE.md` and the files inside `assets_png_preferred/` to the graphics chat.

If a PNG preferred asset is missing, upload the matching file from `assets_original/`.

Do not let the graphics chat fetch logo or player image URLs. Logos and player/person images must be attached as files.

## Belgium W

- Preferred upload: `belgium-w_primary-flag-v1_5cd6e1.png`
- Original asset: `belgium-w_primary-flag-v1_5cd6e1.png`
- Source URL: https://flagcdn.com/w320/be.png
- Status: copied_local; already_png

## Brazil W

- Preferred upload: `brazil-w_primary-flag-v1_ad6ec8.png`
- Original asset: `brazil-w_primary-flag-v1_ad6ec8.png`
- Source URL: https://flagcdn.com/w320/br.png
- Status: copied_local; already_png

## Bulgaria W

- Preferred upload: `bulgaria-w_primary-flag-v1_b54eb4.png`
- Original asset: `bulgaria-w_primary-flag-v1_b54eb4.png`
- Source URL: https://flagcdn.com/w320/bg.png
- Status: copied_local; already_png

## Canada W

- Preferred upload: `canada-w_primary-flag-v1_f75be0.png`
- Original asset: `canada-w_primary-flag-v1_f75be0.png`
- Source URL: https://flagcdn.com/w320/ca.png
- Status: copied_local; already_png

## China W

- Preferred upload: `china-w_primary-flag-v1_869631.png`
- Original asset: `china-w_primary-flag-v1_869631.png`
- Source URL: https://flagcdn.com/w320/cn.png
- Status: copied_local; already_png

## France W

- Preferred upload: `france-w_primary-flag-v1_fe25ad.png`
- Original asset: `france-w_primary-flag-v1_fe25ad.png`
- Source URL: https://flagcdn.com/w320/fr.png
- Status: copied_local; already_png

## Italy W

- Preferred upload: `italy-w_primary-flag-v1_6f4ac2.png`
- Original asset: `italy-w_primary-flag-v1_6f4ac2.png`
- Source URL: https://flagcdn.com/w320/it.png
- Status: copied_local; already_png

## Serbia W

- Preferred upload: `serbia-w_primary-flag-v1_1998ee.png`
- Original asset: `serbia-w_primary-flag-v1_1998ee.png`
- Source URL: https://flagcdn.com/w320/rs.png
- Status: copied_local; already_png

## Thailand W

- Preferred upload: `thailand-w_primary-flag-v1_a1d24e.png`
- Original asset: `thailand-w_primary-flag-v1_a1d24e.png`
- Source URL: https://flagcdn.com/w320/th.png
- Status: copied_local; already_png

## Turkey W

- Preferred upload: `turkey-w_primary-flag-v1_61c372.png`
- Original asset: `turkey-w_primary-flag-v1_61c372.png`
- Source URL: https://flagcdn.com/w320/tr.png
- Status: copied_local; already_png

## USA W

- Preferred upload: `usa-w_primary-flag-v1_287991.png`
- Original asset: `usa-w_primary-flag-v1_287991.png`
- Source URL: https://flagcdn.com/w320/us.png
- Status: copied_local; already_png
