# HSD Pipeline Lite Review

This lite review includes BeBe status files plus ready graphics upload packs when available.

{
  "version": "hsd-pipeline-review-lite-v3.2.13-bebe-ops-v2.11",
  "generated_at_utc": "2026-06-14T17:02:07.869732+00:00",
  "counts": {
    "results_contract_rows": 18,
    "manual_story_candidates": 0,
    "discovery_candidates": 0,
    "slate_items": 1,
    "upload_pack_rows": 1,
    "ready_packs_included": 2,
    "graphics_upload_pack_files_included": 39,
    "manual_workflow_packs_included": 14,
    "ig_story_results_ready_packs_included": 1,
    "ig_story_results_upload_pack_files_included": 10
  },
  "ready_packs": [
    {
      "bundle_name": "Tonight in the W",
      "zip": "hsd_pipeline_lite_review/ready_upload_packs/tonight-in-the-w_graphics_chat_upload_pack.zip",
      "status": "ready_with_review",
      "included": true,
      "size": 607771
    },
    {
      "bundle_name": "tonight-in-the-w_preview-intelligence-v1_companion",
      "zip": "hsd_pipeline_lite_review/ready_upload_packs/tonight-in-the-w_preview-intelligence-v1_companion.zip",
      "status": "found_zip",
      "included": true,
      "size": 5265
    }
  ],
  "ig_story_results_ready_packs": [
    {
      "zip": "hsd_pipeline_lite_review/ig_story_results_ready_upload_packs/last-night-in-the-w_ig_story_results_upload_pack.zip",
      "included": true,
      "size": 54424
    }
  ],
  "max_upload_pack_bytes": 100000000
}
